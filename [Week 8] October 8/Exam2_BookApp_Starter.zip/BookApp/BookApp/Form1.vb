﻿Public Class Form1


    Dim books() As Book = {
            New Book("Nineteen Eighty-Four", "Science Fiction", 19, 24.26),
            New Book("Pride & Prejudice", "Romance", 54, 9.95),
            New Book("Animal Farm", "Satire", 12, 15.15),
            New Book("The Shining", "Horror", 40, 28.99),
            New Book("The War of the Worlds", "Science Fiction", 15, 8.73),
            New Book("Fahrenheit 451", "Science Fiction", 36, 16.99),
            New Book("The Notebook", "Romance", 27, 11.34),
            New Book("Fifty Shades of Grey", "Romance", 10, 24.26),
            New Book("Dracula", "Horror", 34, 13.86),
            New Book("Frankenstein", "Science Fiction", 28, 9.54)
    }

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        bsBooks.DataSource = books
    End Sub

    Private Sub DisplayBook()
        Dim b As Book = bsBooks.Current
        lblGenre.Text = b.Genre
        lblCost.Text = b.Cost.ToString("C")
        lblPrice.Text = b.Price.ToString("C")
        lblQuantity.Text = b.Quantity.ToString()
        lblTitle.Text = b.Title
        lblInventoryValue.Text = b.InventoryValue.ToString("C")
    End Sub

    Private Sub bsBooks_CurrentChanged(sender As Object, e As EventArgs) Handles bsBooks.CurrentChanged
        DisplayBook()
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged

    End Sub

    Private Sub cboGenres_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboGenres.SelectedIndexChanged

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

    End Sub

    Private Sub btnLowerMargin_Click(sender As Object, e As EventArgs) Handles btnLowerMargin.Click

    End Sub

    Private Sub btnRaiseMargin_Click(sender As Object, e As EventArgs) Handles btnRaiseMargin.Click

    End Sub
End Class
